@echo off
REM pptx-maker - Installer for Windows
REM Double-click this file to install.

cd /d "%~dp0"
chcp 65001 >nul 2>&1

REM Remove Zone Identifier to suppress PowerShell security warnings
powershell -NoProfile -Command "Get-ChildItem -Path '%~dp0setup' -Recurse -Filter *.ps1 | Unblock-File" >nul 2>&1

REM Prefer pwsh (PowerShell 7+) if available, fall back to powershell (5.1)
where pwsh >nul 2>&1
if %errorlevel%==0 (
    pwsh -ExecutionPolicy Bypass -NoProfile -File "%~dp0setup\install.ps1"
) else (
    powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0setup\install.ps1"
)

echo.
pause
