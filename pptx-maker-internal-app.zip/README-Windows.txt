========================================
  SDPM Internal Kit — Windows 向けガイド
========================================

AI と対話してスライドを作成するツール「SDPM」の社内配布キットです。


■ クイックスタート (3 ステップ)
────────────────────────────────

1. sdpm-internal-kit.zip をダウンロード → 右クリック → すべて展開
2. 展開フォルダ内の「Install (Windows).cmd」をダブルクリック
   ※「Windows によって PC が保護されました」→「詳細情報」→「実行」
3. デスクトップの「pptx-maker」ショートカットをダブルクリック

ブラウザで http://localhost:3000 が自動で開きます。


■ 初回のみ: kiro-cli の認証
────────────────────────────────

ターミナル (PowerShell) で以下を実行:

  kiro-cli login

案内に従ってブラウザで認証してください。


■ 同梱されているもの
────────────────────────────────

  テンプレート: aws-brand-dark.pptx, aws-brand-light.pptx
  スタイル:     aws-proserve.html, aws-sa-am-premium.html,
                aws-sa-am-simple.html, aws-tam.html
  AWS アイコン: インストール時に自動セットアップ


■ インストーラーは何をする？
────────────────────────────────

1. 必要なツール (git, Node.js, Python, uv, kiro-cli, LibreOffice) を自動インストール
2. OSS 本体を GitHub からダウンロード → 展開キットの隣 (sdpm\)
3. 設定ファイルを %APPDATA%\sdpm\ に配置
4. AWS アイコンを CDN からダウンロード
5. デスクトップに pptx-maker ショートカットを作成
6. ターミナル用の sdpm コマンドを作成

※ テンプレート・スタイルは展開フォルダ内の templates\, styles\ をそのまま使用します。


■ 使い方の流れ
────────────────────────────────

1. デスクトップの pptx-maker をダブルクリック
2. ブラウザで http://localhost:3000 が開く
3. 「新規作成」でスライド作成開始
4. AI と対話しながら内容を詰める
5. 生成されたスライドをプレビュー → pptx ダウンロード

詳細: https://github.com/aws-samples/sample-spec-driven-presentation-maker


■ カスタマイズ
────────────────────────────────

展開フォルダ内のファイルを自由に編集・追加できます:

  <展開フォルダ>\
  ├── templates\    独自 .pptx テンプレートを追加
  └── styles\       独自 .html スタイルを追加

設定ファイル: %APPDATA%\sdpm\config.json

更新時は config.json と手動追加ファイルは保護されます。


■ トラブルシューティング
────────────────────────────────

● SDPM が起動しない
  ターミナルで: sdpm doctor

● ブラウザが自動で開かない
  手動で http://localhost:3000 にアクセス

● sdpm コマンドが見つからない
  インストーラが PATH に追加しますが、ターミナル再起動が必要です。

● ポート 3000 が使用中
  別プロセスが占有している場合はそれを終了してから再実行。

● kiro-cli の認証エラー
  kiro-cli doctor   (状態確認)
  kiro-cli login    (再認証)


■ 更新
────────────────────────────────

「Update (Windows).cmd」をダブルクリック、または:

  sdpm update

- OSS が最新リリースに更新
- 依存パッケージも自動で再インストール
- %APPDATA%\sdpm\ 配下は保護されます

バージョン確認: sdpm version


■ アンインストール
────────────────────────────────

「Uninstall (Windows).cmd」をダブルクリック

手動で削除する場合 (PowerShell):

  Remove-Item -Recurse <キット展開先>\sdpm
  Remove-Item -Recurse $env:APPDATA\sdpm
  Remove-Item $env:USERPROFILE\bin\sdpm.cmd
  Remove-Item "$([Environment]::GetFolderPath('Desktop'))\pptx-maker.lnk"

依存ツールは他の用途にも使われる可能性があるため手動判断してください。


■ サポート
────────────────────────────────

社内 Slack: #sdpm-support
