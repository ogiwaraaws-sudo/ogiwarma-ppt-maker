@echo off
REM pptx-maker - OSS Updater for Windows
REM Double-click this file to fetch the latest SDPM release from GitHub
REM and reinstall web-ui / mcp-local dependencies.

cd /d "%~dp0"
chcp 65001 >nul 2>&1

powershell -NoProfile -Command "Get-ChildItem -Path '%~dp0setup' -Recurse -Filter *.ps1 | Unblock-File" >nul 2>&1

powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0setup\update.ps1"

echo.
pause
