#!/bin/bash
# SDPM Internal Kit — Modern TUI Installer for macOS / Linux
#
# Usage:
#   1. Download sdpm-internal-kit.zip from SharePoint
#   2. Unzip it
#   3. Open the 'setup' folder in Terminal and run: bash install.sh

set -uo pipefail

# ── Configuration ────────────────────────────────────────────────

KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$KIT_DIR/.." && pwd)"
SDPM_ROOT="${SDPM_ROOT:-$ROOT_DIR/sdpm}"
OSS_REPO="aws-samples/sample-spec-driven-presentation-maker"
USER_CONFIG="${XDG_CONFIG_HOME:-$HOME/.config}/sdpm"
LAUNCHER_DIR="$HOME/.local/bin"
KIT_VERSION="0.1.0"

# ── OS detection ─────────────────────────────────────────────────

OS="$(uname -s)"
ARCH="$(uname -m)"
case "$OS" in
  Darwin) OS_TYPE="macos" ;;
  Linux)  OS_TYPE="linux" ;;
  *)      echo "Unsupported OS: $OS" >&2; exit 1 ;;
esac

# ── Shared TUI helpers ─────────────────────────────────────────
# shellcheck disable=SC1091
source "$KIT_DIR/lib/tui.sh"

# ── Phase 1: Environment Check ───────────────────────────────────

# Parallel arrays (bash 3.2 compatible — macOS default)
DEP_NAMES=()
DEP_VERSIONS=()
DEP_FOUND=()
DEP_REASONS=()
DEP_HELP=()

_add_dep() {
  DEP_NAMES+=("$1")
  DEP_VERSIONS+=("$2")
  DEP_FOUND+=("$3")
  DEP_REASONS+=("$4")
  DEP_HELP+=("$5")
}

scan_dependencies() {
  DEP_NAMES=(); DEP_VERSIONS=(); DEP_FOUND=(); DEP_REASONS=(); DEP_HELP=()

  # package manager (macos only — Homebrew; Linux uses apt, always present on Ubuntu)
  if [[ "$OS_TYPE" == "macos" ]]; then
    if has_command brew; then _add_dep "Homebrew" "(package manager)" "1" "auto-install" "https://brew.sh/"
    else _add_dep "Homebrew" "" "0" "auto-install" "https://brew.sh/"
    fi
  fi

  # git
  if has_command git; then _add_dep "git" "$(git --version | awk '{print $3}')" "1" "latest version fetch" "https://git-scm.com/"
  else _add_dep "git" "" "0" "latest version fetch" "https://git-scm.com/"
  fi

  # Node.js
  if has_command node; then _add_dep "Node.js" "$(node --version)" "1" "slide engine" "https://nodejs.org/"
  else _add_dep "Node.js" "" "0" "slide engine" "https://nodejs.org/"
  fi

  # Python 3.10+
  local pyok=0 pyver=""
  if has_command python3; then
    pyver="$(python3 -c 'import sys;print(f"{sys.version_info[0]}.{sys.version_info[1]}")' 2>/dev/null)"
    if [[ -n "$pyver" ]] && [[ "$(printf '%s\n' '3.10' "$pyver" | sort -V | head -1)" == "3.10" ]]; then
      pyok=1
    fi
  fi
  _add_dep "Python" "$pyver" "$pyok" "AI integration" "https://www.python.org/downloads/"

  # uv
  if has_command uv; then _add_dep "uv" "$(uv --version | awk '{print $2}')" "1" "Python packages" "https://docs.astral.sh/uv/"
  else _add_dep "uv" "" "0" "Python packages" "https://docs.astral.sh/uv/"
  fi

  # kiro-cli
  if has_command kiro-cli; then _add_dep "kiro-cli" "installed" "1" "AI service" "https://cli.kiro.dev/"
  else _add_dep "kiro-cli" "" "0" "AI service" "https://cli.kiro.dev/"
  fi

  # LibreOffice
  local libre_found=0 libre_ver=""
  if [[ "$OS_TYPE" == "macos" ]]; then
    if [[ -d "/Applications/LibreOffice.app" ]]; then
      libre_found=1
      libre_ver="$(defaults read "/Applications/LibreOffice.app/Contents/Info.plist" CFBundleShortVersionString 2>/dev/null || echo "")"
    fi
  else
    if has_command libreoffice || has_command soffice; then
      libre_found=1
      libre_ver="$(libreoffice --version 2>/dev/null | awk '{print $2}')"
    fi
  fi
  _add_dep "LibreOffice" "$libre_ver" "$libre_found" "pptx preview" "https://www.libreoffice.org/download/"
}

# ── Phase 2: Install missing dependencies ────────────────────────

refresh_path() { export PATH="$HOME/.local/bin:$PATH"; }

install_dep_homebrew() {
  start_step "Homebrew をインストール中" "macOS のパッケージ管理に必要です"
  fail_step "Homebrew は自動インストールできません" "" "https://brew.sh/"
  exit 1
}

install_dep_git() {
  start_step "git をインストール中" "最新版の取得に必要です"
  local cmd
  if [[ "$OS_TYPE" == "macos" ]]; then cmd="brew install git"
  else cmd="sudo apt-get install -y git"
  fi
  if run_with_spinner "$cmd"; then complete_step "git をインストールしました (${LAST_ELAPSED})"
  else fail_step "git のインストールに失敗しました" "$LAST_LOG" "https://git-scm.com/"; exit 1
  fi
}

install_dep_node() {
  start_step "Node.js をインストール中" "スライド生成エンジンに必要です"
  local cmd
  if [[ "$OS_TYPE" == "macos" ]]; then cmd="brew install node"
  else cmd="curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt-get install -y nodejs"
  fi
  if run_with_spinner "$cmd"; then complete_step "Node.js をインストールしました (${LAST_ELAPSED})"
  else fail_step "Node.js のインストールに失敗しました" "$LAST_LOG" "https://nodejs.org/"; exit 1
  fi
}

install_dep_python() {
  start_step "Python をインストール中" "AI連携に必要です"
  local cmd
  if [[ "$OS_TYPE" == "macos" ]]; then cmd="brew install python@3.12"
  else cmd="sudo apt-get update && sudo apt-get install -y python3.12 python3.12-venv"
  fi
  if run_with_spinner "$cmd"; then complete_step "Python をインストールしました (${LAST_ELAPSED})"
  else fail_step "Python のインストールに失敗しました" "$LAST_LOG" "https://www.python.org/downloads/"; exit 1
  fi
}

install_dep_uv() {
  start_step "uv をインストール中" "Pythonパッケージ管理に必要です"
  if run_with_spinner "curl -LsSf https://astral.sh/uv/install.sh | sh"; then
    refresh_path
    complete_step "uv をインストールしました (${LAST_ELAPSED})"
  else fail_step "uv のインストールに失敗しました" "$LAST_LOG" "https://docs.astral.sh/uv/"; exit 1
  fi
}

install_dep_kiro_cli() {
  start_step "kiro-cli をインストール中" "AI サービス連携に必要です"
  local cmd
  if [[ "$OS_TYPE" == "macos" ]]; then
    cmd="curl -fsSL https://cli.kiro.dev/install | bash"
  else
    mkdir -p "$HOME/.local/bin"
    local arch_tag
    case "$ARCH" in
      x86_64|amd64) arch_tag="x86_64" ;;
      aarch64|arm64) arch_tag="aarch64" ;;
      *) fail_step "Unsupported architecture: $ARCH" "" "https://cli.kiro.dev/"; exit 1 ;;
    esac
    cmd="curl -fsSL https://desktop-release.q.us-east-1.amazonaws.com/latest/kiro-cli.appimage -o '$HOME/.local/bin/kiro-cli' && chmod +x '$HOME/.local/bin/kiro-cli'"
  fi
  if run_with_spinner "$cmd"; then
    refresh_path
    complete_step "kiro-cli をインストールしました (${LAST_ELAPSED})"
  else fail_step "kiro-cli のインストールに失敗しました" "$LAST_LOG" "https://cli.kiro.dev/"; exit 1
  fi
}

install_dep_libreoffice() {
  start_step "LibreOffice をインストール中" "スライドのプレビューに必要です（約500MB）"
  local cmd
  if [[ "$OS_TYPE" == "macos" ]]; then cmd="brew install --cask libreoffice"
  else cmd="sudo apt-get install -y libreoffice"
  fi
  if run_with_spinner "$cmd"; then complete_step "LibreOffice をインストールしました (${LAST_ELAPSED})"
  else fail_step "LibreOffice のインストールに失敗しました" "$LAST_LOG" "https://www.libreoffice.org/download/"; exit 1
  fi
}

# ── Phase 3: Setup ───────────────────────────────────────────────

RAYCAST_AWS_ICONS="$HOME/Library/Application Support/com.raycast.macos/extensions/aws-icons"

_resolve_ref() {
  local repo_path="$1" tag
  tag=$(git -C "$repo_path" tag --sort=-v:refname 2>/dev/null | head -1)
  if [[ -n "$tag" ]]; then echo "$tag"; else echo "main"; fi
}

setup_oss() {
  start_step "SDPM 本体をダウンロード中" "-> $SDPM_ROOT"
  git config --global --add safe.directory "$SDPM_ROOT" >/dev/null 2>&1 || true
  if [[ -d "$SDPM_ROOT/.git" ]]; then
    if run_with_spinner "git -C '$SDPM_ROOT' fetch --tags --prune"; then
      local ref
      ref=$(_resolve_ref "$SDPM_ROOT")
      git -C "$SDPM_ROOT" checkout -q "$ref" >/dev/null 2>&1 || true
      if [[ "$ref" == "main" ]]; then
        git -C "$SDPM_ROOT" pull --ff-only >/dev/null 2>&1 || true
      fi
      complete_step "SDPM 本体を更新しました ($ref)"
    else
      fail_step "更新に失敗しました" "$LAST_LOG" "https://github.com/$OSS_REPO"; exit 1
    fi
  else
    rm -rf "$SDPM_ROOT"
    if run_with_spinner "git clone --quiet https://github.com/$OSS_REPO.git '$SDPM_ROOT'"; then
      local ref
      ref=$(_resolve_ref "$SDPM_ROOT")
      git -C "$SDPM_ROOT" checkout -q "$ref" >/dev/null 2>&1 || true
      complete_step "SDPM 本体を取得しました ($ref)"
    else
      fail_step "ダウンロードに失敗しました" "$LAST_LOG" "https://github.com/$OSS_REPO"; exit 1
    fi
  fi
}

setup_oss_deps() {
  local webui="$SDPM_ROOT/web-ui" mcp="$SDPM_ROOT/mcp-local"
  local need_npm=0 need_uv=0
  [[ -d "$webui/node_modules" ]] || need_npm=1
  [[ -d "$mcp/.venv" ]]          || need_uv=1

  if [[ $need_npm -eq 0 && $need_uv -eq 0 ]]; then
    start_step "パッケージ（スキップ）" "既にインストール済みです"
    complete_step "パッケージは既にインストール済み"
    return
  fi
  start_step "パッケージをインストール中" "-> web-ui / mcp-local (初回 2-3 分)"

  if [[ $need_npm -eq 1 ]]; then
    if ! run_with_spinner "npm ci" "$webui"; then
      fail_step "npm ci に失敗しました" "$LAST_LOG"; exit 1
    fi
  fi
  if [[ $need_uv -eq 1 ]]; then
    if ! run_with_spinner "uv sync" "$mcp"; then
      fail_step "uv sync に失敗しました" "$LAST_LOG"; exit 1
    fi
  fi
  complete_step "パッケージをインストールしました"
}

setup_assets() {
  start_step "設定ファイルを配置中" "-> $USER_CONFIG"
  mkdir -p "$USER_CONFIG"
  for d in templates styles assets; do
    if [[ -d "$KIT_DIR/../$d" ]] && [[ -n "$(ls -A "$KIT_DIR/../$d" 2>/dev/null)" ]]; then
      mkdir -p "$USER_CONFIG/$d"
      cp -R "$KIT_DIR/../$d/." "$USER_CONFIG/$d/"
    fi
  done
  if [[ -f "$KIT_DIR/config.json" ]] && [[ ! -f "$USER_CONFIG/config.json" ]]; then
    cp "$KIT_DIR/config.json" "$USER_CONFIG/config.json"
  fi
  complete_step "設定ファイルを配置しました"
}

_configure_extra_source_raycast() {
  local cfg="$USER_CONFIG/config.json"
  mkdir -p "$USER_CONFIG"
  python3 - "$cfg" "$RAYCAST_AWS_ICONS" <<'PY'
import json, sys
from pathlib import Path
cfg_path = Path(sys.argv[1])
raycast_dir = sys.argv[2]
data = {}
if cfg_path.exists():
    data = json.loads(cfg_path.read_text())
data.setdefault("extra_sources", [])
entry = {
    "source": "aws-internal",
    "manifest": f"{raycast_dir}/manifest.json",
    "files_dir": f"{raycast_dir}/icons",
    "recolorProtected": {"when": {"type": ["service", "resource", "category", "group", "third-party"]}},
}
data["extra_sources"] = [e for e in data["extra_sources"] if e.get("source") != "aws-internal"]
data["extra_sources"].append(entry)
cfg_path.write_text(json.dumps(data, indent=2))
PY
}

setup_aws_icons() {
  local oss_dest="$SDPM_ROOT/skill/assets/aws"
  if [[ -d "$oss_dest" ]] && [[ -f "$oss_dest/manifest.json" ]]; then
    start_step "AWS アイコン（スキップ）" "既にインストール済みです"
    complete_step "AWS アイコンは既にインストール済み"
    return
  fi
  # Raycast AWS Icons reuse path (macOS only)
  if [[ "$OS_TYPE" == "macos" ]] && [[ -f "$RAYCAST_AWS_ICONS/manifest.json" ]]; then
    start_step "AWS アイコンを Raycast から参照" "-> extra_sources を設定"
    _configure_extra_source_raycast
    complete_step "Raycast AWS Icons を参照する設定を追加しました"
    return
  fi
  start_step "AWS アイコンをダウンロード中" "-> $oss_dest (公式 AWS Architecture Icons)"
  if run_with_spinner "python3 '$SDPM_ROOT/skill/scripts/download_aws_icons.py'"; then
    complete_step "AWS アイコンをダウンロードしました (${LAST_ELAPSED})"
  else
    fail_step "AWS アイコンのダウンロードに失敗しました（後で再試行可能）" "$LAST_LOG"
  fi
}

setup_material_icons() {
  local oss_dest="$SDPM_ROOT/skill/assets/material"
  if [[ -d "$oss_dest" ]] && [[ -f "$oss_dest/manifest.json" ]]; then
    start_step "Material アイコン（スキップ）" "既にインストール済みです"
    complete_step "Material アイコンは既にインストール済み"
    return
  fi
  start_step "Material アイコンをダウンロード中" "-> $oss_dest (Google Material Symbols)"
  if run_with_spinner "python3 '$SDPM_ROOT/skill/scripts/download_material_icons.py'"; then
    complete_step "Material アイコンをダウンロードしました (${LAST_ELAPSED})"
  else
    fail_step "Material アイコンのダウンロードに失敗しました（後で再試行可能）" "$LAST_LOG"
  fi
}

setup_launcher() {
  start_step "コマンドを作成中" "-> $LAUNCHER_DIR/sdpm"
  mkdir -p "$LAUNCHER_DIR"
  cat > "$LAUNCHER_DIR/sdpm" <<EOF
#!/bin/bash
# SDPM launcher (generated by sdpm-internal-kit installer)
set -eo pipefail
SDPM_ROOT="$SDPM_ROOT"
USER_CONFIG="$USER_CONFIG"

MARKER_FILE="\$SDPM_ROOT/.update-available"
LAST_CHECK_FILE="\$SDPM_ROOT/.last-update-check"
CHECK_INTERVAL_SECONDS=\$((24 * 60 * 60))

_open() {
  if command -v open >/dev/null 2>&1; then open "\$1"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "\$1"
  fi
}

_check_update_async() {
  [[ -d "\$SDPM_ROOT/.git" ]] || return 0
  if [[ -f "\$LAST_CHECK_FILE" ]]; then
    local now last age
    now=\$(date +%s); last=\$(cat "\$LAST_CHECK_FILE" 2>/dev/null || echo 0)
    age=\$((now - last))
    [[ \$age -lt \$CHECK_INTERVAL_SECONDS ]] && return
  fi
  (
    local latest current
    latest=\$(git -C "\$SDPM_ROOT" ls-remote --tags --refs --sort=-v:refname origin 2>/dev/null | head -1 | sed 's#.*/##')
    current=\$(git -C "\$SDPM_ROOT" describe --tags --abbrev=0 2>/dev/null || echo "")
    date +%s > "\$LAST_CHECK_FILE" 2>/dev/null || true
    if [[ -n "\$latest" ]] && [[ "\$latest" != "\$current" ]]; then
      echo "\$latest" > "\$MARKER_FILE"
    else
      rm -f "\$MARKER_FILE"
    fi
  ) >/dev/null 2>&1 &
  disown 2>/dev/null || true
}

_show_update_banner_if_any() {
  [[ -f "\$MARKER_FILE" ]] || return 0
  local new_ver current
  new_ver=\$(cat "\$MARKER_FILE")
  current=\$(git -C "\$SDPM_ROOT" describe --tags --abbrev=0 2>/dev/null || echo "?")
  echo ""
  echo "─────────────────────────────────────────────────────"
  echo "  📢 新しいバージョンが利用できます: \$current → \$new_ver"
  echo "     更新するには: sdpm update"
  echo "─────────────────────────────────────────────────────"
  echo ""
}

_wait_for_port_and_open_browser() {
  # Poll 127.0.0.1:3000 up to 120s (500ms interval), then open browser.
  (
    local i
    for i in \$(seq 1 240); do
      if (exec 3<>/dev/tcp/127.0.0.1/3000) 2>/dev/null; then
        exec 3<&- 2>/dev/null
        _open "http://localhost:3000"
        exit 0
      fi
      sleep 0.5
    done
  ) &
  disown 2>/dev/null || true
}

launch_webui() {
  _show_update_banner_if_any
  if lsof -i :3000 >/dev/null 2>&1; then
    echo "SDPM is already running. Opening browser..."
    _open "http://localhost:3000"
    exit 0
  fi
  _check_update_async
  _wait_for_port_and_open_browser
  cd "\$SDPM_ROOT/web-ui" && NEXT_PUBLIC_MODE=local npm run dev:local
}

update_oss() {
  if [[ ! -d "\$SDPM_ROOT/.git" ]]; then
    echo "✗ \$SDPM_ROOT is not a git repository."
    echo "  Re-run the Install (macOS).command to reinstall."
    exit 1
  fi
  echo "▶ Fetching latest changes..."
  git -C "\$SDPM_ROOT" fetch --tags --prune
  local tag
  tag=\$(git -C "\$SDPM_ROOT" tag --sort=-v:refname | head -1)
  if [[ -n "\$tag" ]]; then
    git -C "\$SDPM_ROOT" checkout -q "\$tag"
    echo "✓ Checked out latest release: \$tag"
  else
    git -C "\$SDPM_ROOT" checkout -q main
    git -C "\$SDPM_ROOT" pull --ff-only
    echo "✓ Updated to latest main"
  fi
  echo "▶ Updating web-ui dependencies..."
  (cd "\$SDPM_ROOT/web-ui" && npm ci)
  echo "▶ Updating mcp-local dependencies..."
  (cd "\$SDPM_ROOT/mcp-local" && uv sync)
  rm -f "\$MARKER_FILE"
  echo ""
  echo "✅ Update complete. Run 'sdpm' to launch."
}

check_update_now() {
  [[ -d "\$SDPM_ROOT/.git" ]] || { echo "Not a git repository: \$SDPM_ROOT"; exit 1; }
  echo "Checking for updates..."
  local latest current
  latest=\$(git -C "\$SDPM_ROOT" ls-remote --tags --refs --sort=-v:refname origin 2>/dev/null | head -1 | sed 's#.*/##')
  current=\$(git -C "\$SDPM_ROOT" describe --tags --abbrev=0 2>/dev/null || echo "")
  date +%s > "\$LAST_CHECK_FILE" 2>/dev/null || true
  if [[ -z "\$latest" ]]; then echo "Could not fetch latest tag."; exit 1; fi
  if [[ "\$latest" == "\$current" ]]; then
    echo "✓ Already on the latest release: \$current"
    rm -f "\$MARKER_FILE"
  else
    echo "📢 New version available: \$current → \$latest"
    echo "   Run 'sdpm update' to upgrade."
    echo "\$latest" > "\$MARKER_FILE"
  fi
}

version_info() {
  if [[ -d "\$SDPM_ROOT/.git" ]]; then
    local ref commit
    ref=\$(git -C "\$SDPM_ROOT" describe --tags --always 2>/dev/null || echo "?")
    commit=\$(git -C "\$SDPM_ROOT" rev-parse --short HEAD 2>/dev/null || echo "?")
    echo "SDPM version: \$ref (\$commit)"
  else
    echo "SDPM_ROOT is not a git repository: \$SDPM_ROOT"
  fi
}

open_target() {
  case "\${1:-}" in
    app)       _open "\$SDPM_ROOT" ;;
    config)    _open "\$USER_CONFIG" ;;
    templates) _open "\$USER_CONFIG/templates" ;;
    styles)    _open "\$USER_CONFIG/styles" ;;
    icons)     _open "\$SDPM_ROOT/skill/assets/aws" ;;
    *) cat <<HELP
Usage: sdpm open [target]

Targets:
  app         SDPM source (\$SDPM_ROOT)
  config      User config (\$USER_CONFIG)
  templates   Templates folder
  styles      Styles folder
  icons       AWS icons folder
HELP
       ;;
  esac
}

case "\${1:-launch}" in
  launch|"") launch_webui ;;
  update)       update_oss ;;
  check-update) check_update_now ;;
  version|--version|-v) version_info ;;
  path)         echo "\$SDPM_ROOT" ;;
  open)         open_target "\${2:-}" ;;
  doctor)
    echo "Checking SDPM environment..."
    for c in git node python3 uv kiro-cli; do
      if command -v \$c >/dev/null 2>&1; then
        echo "  ✓ \$c: \$(\$c --version 2>&1 | head -1)"
      else
        echo "  ✗ \$c: not found"
      fi
    done
    [[ -d "\$SDPM_ROOT" ]] && echo "  ✓ SDPM_ROOT: \$SDPM_ROOT" || echo "  ✗ SDPM_ROOT missing: \$SDPM_ROOT"
    version_info
    ;;
  help|--help|-h)
    cat <<HELP
Usage: sdpm [COMMAND]

Commands:
  launch        Start SDPM Web UI (default, opens browser)
  open [target] Open folder (app/config/templates/styles/icons)
  update        Update OSS to latest release and reinstall dependencies
  check-update  Check for updates without applying
  version       Show installed SDPM version
  path          Print SDPM_ROOT
  doctor        Show environment diagnostics
  help          Show this help
HELP
    ;;
  *) echo "Unknown command: \$1"; echo "Run 'sdpm help' for usage."; exit 1 ;;
esac
EOF
  chmod +x "$LAUNCHER_DIR/sdpm"
  complete_step "sdpm コマンドを作成しました"
}

setup_shortcut() {
  start_step "ショートカットを作成中" "-> デスクトップ"
  local desktop
  if [[ "$OS_TYPE" == "macos" ]]; then
    desktop="$HOME/Desktop"
    if [[ ! -d "$desktop" ]]; then complete_step "デスクトップが見つかりません（スキップ）"; return; fi
    cat > "$desktop/pptx-maker.command" <<EOF
#!/bin/bash
# pptx-maker — double-click to open the Web UI
exec "$LAUNCHER_DIR/sdpm"
EOF
    chmod +x "$desktop/pptx-maker.command"
    complete_step "デスクトップにショートカットを作成しました (pptx-maker.command)"
  else
    local apps="$HOME/.local/share/applications"
    mkdir -p "$apps"
    cat > "$apps/pptx-maker.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=pptx-maker
Comment=SDPM Web UI
Exec=$LAUNCHER_DIR/sdpm
Terminal=true
Categories=Office;Presentation;
EOF
    chmod +x "$apps/pptx-maker.desktop"
    complete_step "アプリケーションエントリを作成しました"
  fi
}

check_path() {
  if [[ ":$PATH:" != *":$LAUNCHER_DIR:"* ]]; then
    echo ""
    printf "    ${C_YELLOW}⚠  %s が PATH に含まれていません${C_RESET}\n" "$LAUNCHER_DIR"
    printf "    ${C_DIM}~/.zshrc または ~/.bashrc に追加してください:${C_RESET}\n"
    printf "    ${C_DIM}  export PATH=\"\$HOME/.local/bin:\$PATH\"${C_RESET}\n"
  fi
}

# ── Phase 4: Completion ──────────────────────────────────────────

show_completion() {
  echo ""
  echo ""
  printf "  ${C_GREEN}╭───────────────────────────────────────────╮${C_RESET}\n"
  printf "  ${C_GREEN}│  🎉 セットアップが完了しました！             │${C_RESET}\n"
  printf "  ${C_GREEN}╰───────────────────────────────────────────╯${C_RESET}\n"
  echo ""
  printf "    インストール先:\n"
  printf "      ${C_DIM}SDPM 本体      %s${C_RESET}\n" "$SDPM_ROOT"
  printf "      ${C_DIM}ユーザー設定    %s${C_RESET}\n" "$USER_CONFIG"
  printf "      ${C_DIM}コマンド        %s/sdpm${C_RESET}\n" "$LAUNCHER_DIR"
  echo ""
  printf "    起動方法:\n"
  if [[ "$OS_TYPE" == "macos" ]]; then
    printf "      • デスクトップの「pptx-maker」をダブルクリック\n"
  else
    printf "      • アプリケーションメニューから「pptx-maker」を選択\n"
  fi
  printf "      • またはターミナルで: sdpm\n"
  echo ""
}

run_kiro_login() {
  if ! has_command kiro-cli; then return; fi
  local output status
  output="$(kiro-cli login 2>&1 || true)"
  if echo "$output" | grep -qi "Already logged in"; then
    printf "    ${C_GREEN}✓${C_RESET} kiro-cli 認証済み\n"
  else
    printf "    ${C_GREEN}✓${C_RESET} kiro-cli 認証完了\n"
  fi
}

# ── Main ─────────────────────────────────────────────────────────

main() {
  show_header "🚀 SDPM セットアップ" "$KIT_VERSION"

  # Phase 1
  printf "    ${C_DIM}環境を確認しています...${C_RESET}\n"
  echo ""
  scan_dependencies
  local i count=${#DEP_NAMES[@]}
  for (( i=0; i<count; i++ )); do
    show_check "${DEP_NAMES[i]}" "${DEP_VERSIONS[i]}" "${DEP_FOUND[i]}"
  done
  echo ""

  # macOS: Homebrew required
  if [[ "$OS_TYPE" == "macos" ]] && [[ "${DEP_FOUND[0]}" != "1" ]]; then
    printf "    ${C_RED}✗ Homebrew が見つかりません${C_RESET}\n"
    printf "      ${C_DIM}先に Homebrew をインストールしてください:${C_RESET}\n"
    printf "      ${C_DIM}/bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"${C_RESET}\n"
    exit 1
  fi

  # Missing deps (excluding Homebrew which we exit on)
  local missing_idx=()
  for (( i=0; i<count; i++ )); do
    if [[ "${DEP_FOUND[i]}" != "1" ]] && [[ "${DEP_NAMES[i]}" != "Homebrew" ]]; then
      missing_idx+=("$i")
    fi
  done

  if [[ ${#missing_idx[@]} -gt 0 ]]; then
    printf "  ${C_DIM}─────────────────────────────────────────────${C_RESET}\n"
    printf "    %d 件のツールをインストールします:\n" "${#missing_idx[@]}"
    echo ""
    for i in "${missing_idx[@]}"; do
      printf "      • %s  ${C_DIM}— %s${C_RESET}\n" "${DEP_NAMES[i]}" "${DEP_REASONS[i]}"
    done
    if ! show_confirm "続行しますか？ [Y/n]"; then
      echo ""
      printf "    ${C_YELLOW}手動インストール用リンク:${C_RESET}\n"
      for i in "${missing_idx[@]}"; do
        printf "      ${C_DIM}%s: %s${C_RESET}\n" "${DEP_NAMES[i]}" "${DEP_HELP[i]}"
      done
      echo ""
      printf "    ${C_DIM}インストール後に再度 Install (macOS).command を実行してください。${C_RESET}\n"
      echo ""
      exit 0
    fi
  else
    printf "    ${C_GREEN}すべてのツールが揃っています ✓${C_RESET}\n"
  fi

  TOTAL_STEPS=$(( ${#missing_idx[@]} + 7 ))  # deps + OSS + ossdeps + assets + aws-icons + material-icons + launcher + shortcut

  # Phase 2: Install missing deps
  # Guard against bash 3.2 `set -u` + empty-array expansion (all deps present).
  if [[ ${#missing_idx[@]} -gt 0 ]]; then
    for i in "${missing_idx[@]}"; do
      case "${DEP_NAMES[i]}" in
        git)         install_dep_git ;;
        Node.js)     install_dep_node ;;
        Python)      install_dep_python ;;
        uv)          install_dep_uv ;;
        kiro-cli)    install_dep_kiro_cli ;;
        LibreOffice) install_dep_libreoffice ;;
      esac
    done
  fi

  # Phase 3: Setup
  setup_oss
  setup_oss_deps
  setup_assets
  setup_aws_icons
  setup_material_icons
  setup_launcher
  setup_shortcut

  # Phase 4: Completion
  show_completion
  run_kiro_login
  check_path

  echo ""
  printf "  ${C_DIM}─────────────────────────────────────────────${C_RESET}\n"
  echo ""
  printf "    ${C_GREEN}準備完了！次回から以下の方法で起動できます:${C_RESET}\n"
  echo ""
  if [[ "$OS_TYPE" == "macos" ]]; then
    printf "      • デスクトップの「pptx-maker」をダブルクリック\n"
  else
    printf "      • アプリケーションメニューから「pptx-maker」を選択\n"
  fi
  printf "      • またはターミナルで: sdpm\n"
  echo ""
}

main "$@"
