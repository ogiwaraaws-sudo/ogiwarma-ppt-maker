# Changelog

## v0.1.0 — 2026-04-30

### Initial release

#### Distribution
- Installers for macOS / Linux (`install.sh`) and Windows 11 (`install.ps1`)
- **Double-click launchers**: `Install.command` (macOS) / `Install.cmd` (Windows) for non-engineer users
- Desktop shortcut auto-generated (`SDPM.command` / `SDPM.lnk`) for one-click Web UI launch
- Auto-installs dependencies: Node.js, Python 3.10+, uv, kiro-cli
- Fetches OSS from GitHub latest release (fallback to main)
- Browser auto-open on launch

#### Bundled internal assets
- Templates: `aws-brand-dark.pptx`, `aws-brand-light.pptx`
- Styles: `aws-proserve.html`, `aws-sa-am-premium.html`, `aws-sa-am-simple.html`

#### AWS icons
- Auto-setup based on environment:
  - macOS with Raycast AWS Icons extension → reuse via `extra_sources`
  - Otherwise → download from CDN into `~/.config/sdpm/assets/aws-internal/`

#### Launcher commands
- `sdpm` / `sdpm launch`: start Web UI (with browser auto-open and port 3000 check)
- `sdpm update`: fetch latest OSS via `git pull`, reinstall dependencies
- `sdpm check-update`: check for new version without applying
- `sdpm version`: show installed SDPM version (tag + commit)
- `sdpm doctor`: environment diagnosis
- `sdpm path`: show `$SDPM_ROOT`
- `sdpm help`: show command list

#### Background update notification
- Runs `git ls-remote --tags` in background on launch (non-blocking, ~1s)
- Rate-limited to once per 24 hours via `~/.sdpm/.last-update-check`
- Shows banner on next launch if new version exists (via `.update-available` marker)
- Update is never auto-applied — user decides when to run `sdpm update`

#### OSS fetch & update
- Uses `git clone` / `git pull` (replaces curl + tar approach)
- git is auto-installed via brew/winget/apt if not present
- Checks out latest release tag, falls back to `main` if no tags exist

#### Paths
- OSS: `~/.sdpm/` (hidden, following nvm/pyenv/cargo convention)
- User config: `~/.config/sdpm/` (macOS/Linux) or `%APPDATA%\sdpm\` (Windows)
- Launcher: `~/.local/bin/sdpm` (macOS/Linux) or `%USERPROFILE%\bin\sdpm.cmd` (Windows)
