#!/bin/bash
# SDPM Internal Kit — OSS Updater (TUI) for macOS / Linux
#
# Fetches the latest SDPM release from GitHub and reinstalls dependencies.

set -uo pipefail

KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$KIT_DIR/.." && pwd)"
SDPM_ROOT="${SDPM_ROOT:-$ROOT_DIR/sdpm}"
KIT_VERSION="0.1.0"

# shellcheck disable=SC1091
source "$KIT_DIR/lib/tui.sh"

show_completion_box() {
  local from="$1" to="$2"
  echo ""
  echo ""
  printf "  ${C_GREEN}╭───────────────────────────────────────────╮${C_RESET}\n"
  printf "  ${C_GREEN}│  🎉 アップデートが完了しました！             │${C_RESET}\n"
  printf "  ${C_GREEN}╰───────────────────────────────────────────╯${C_RESET}\n"
  echo ""
  printf "    ${C_DIM}%s → %s${C_RESET}\n" "$from" "$to"
  echo ""
  printf "    起動方法:\n"
  printf "      • デスクトップの「pptx-maker」をダブルクリック\n"
  printf "      • またはターミナルで: sdpm\n"
  echo ""
}

# ── Preflight ──────────────────────────────────────────────────

main() {
  show_header "🔄 SDPM アップデート" "$KIT_VERSION"

  if [[ ! -d "$SDPM_ROOT/.git" ]]; then
    printf "    ${C_RED}✗ SDPM がまだインストールされていません${C_RESET}\n"
    printf "      ${C_DIM}%s${C_RESET}\n" "$SDPM_ROOT"
    printf "      ${C_DIM}先に Install (macOS).command を実行してください。${C_RESET}\n"
    echo ""
    exit 1
  fi

  printf "    ${C_DIM}バージョンを確認しています...${C_RESET}\n"
  echo ""

  # Fetch latest refs (quick, ~1s) — spinner wraps it
  TOTAL_STEPS=3  # fetch-and-checkout, web-ui deps, mcp-local deps
  CURRENT_STEP=0

  local current latest
  current="$(git -C "$SDPM_ROOT" describe --tags --abbrev=0 2>/dev/null || echo '?')"

  # Peek at remote latest tag (not a tracked step; just informational)
  latest="$(git -C "$SDPM_ROOT" ls-remote --tags --refs --sort=-v:refname origin 2>/dev/null \
            | head -1 | sed 's#.*/##')"
  if [[ -z "$latest" ]]; then
    printf "    ${C_RED}✗ GitHub から最新バージョンを取得できませんでした${C_RESET}\n"
    printf "      ${C_DIM}ネットワーク接続を確認してください。${C_RESET}\n"
    echo ""
    exit 1
  fi

  printf "    現在  ${C_GREEN}%s${C_RESET}\n" "$current"
  printf "    最新  ${C_CYAN}%s${C_RESET}\n" "$latest"
  echo ""

  if [[ "$current" == "$latest" ]]; then
    printf "  ${C_DIM}─────────────────────────────────────────────${C_RESET}\n"
    printf "    ${C_GREEN}既に最新バージョンです ✓${C_RESET}\n"
    echo ""
    rm -f "$SDPM_ROOT/.update-available"
    exit 0
  fi

  printf "  ${C_DIM}─────────────────────────────────────────────${C_RESET}\n"
  printf "    新しいバージョンをインストールします。\n"
  if ! show_confirm "続行しますか？ [Y/n]"; then
    echo ""
    printf "    ${C_YELLOW}キャンセルしました。${C_RESET}\n"
    echo ""
    exit 0
  fi

  # ── Step 1: fetch + checkout ──
  start_step "最新コードを取得中" "-> $latest"
  if ! run_with_spinner "git -C '$SDPM_ROOT' fetch --tags --prune"; then
    fail_step "fetch に失敗しました" "$LAST_LOG" "https://github.com/aws-samples/sample-spec-driven-presentation-maker"
    exit 1
  fi
  if ! git -C "$SDPM_ROOT" checkout -q "$latest" 2>/dev/null; then
    fail_step "checkout に失敗しました ($latest)" ""
    exit 1
  fi
  complete_step "$latest に更新しました (${LAST_ELAPSED})"

  # ── Step 2: web-ui deps ──
  start_step "Web UI パッケージを更新中" "-> npm ci (初回 1-2 分)"
  if run_with_spinner "npm ci" "$SDPM_ROOT/web-ui"; then
    complete_step "Web UI パッケージを更新しました (${LAST_ELAPSED})"
  else
    fail_step "npm ci に失敗しました" "$LAST_LOG"
    exit 1
  fi

  # ── Step 3: mcp-local deps ──
  start_step "MCP パッケージを更新中" "-> uv sync"
  if run_with_spinner "uv sync" "$SDPM_ROOT/mcp-local"; then
    complete_step "MCP パッケージを更新しました (${LAST_ELAPSED})"
  else
    fail_step "uv sync に失敗しました" "$LAST_LOG"
    exit 1
  fi

  rm -f "$SDPM_ROOT/.update-available"

  show_completion_box "$current" "$latest"
}

main "$@"
