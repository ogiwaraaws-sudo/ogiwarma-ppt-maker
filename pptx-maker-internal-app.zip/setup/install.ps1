﻿# SDPM Internal Kit — Modern TUI Installer for Windows
#
# Usage:
#   1. Download sdpm-internal-kit.zip from SharePoint
#   2. Right-click → Extract All
#   3. Double-click Install.cmd
#
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[System.Console]::InputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"

# ── Configuration ────────────────────────────────────────────────

$KitDir      = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $KitDir) { $KitDir = $PSScriptRoot }
$RootDir     = Split-Path -Parent $KitDir
$SdpmRoot    = if ($env:SDPM_ROOT) { $env:SDPM_ROOT } else { "$RootDir\sdpm" }
$OssRepo     = "aws-samples/sample-spec-driven-presentation-maker"
$UserConfig  = "$env:APPDATA\sdpm"
$LauncherDir = "$env:USERPROFILE\bin"
$KitVersion  = "0.1.0"

# ── Shared TUI helpers ─────────────────────────────────────────
$_tuiPath = Join-Path $KitDir 'lib\tui.ps1'
if (-not (Test-Path $_tuiPath)) {
    Write-Host "ERROR: TUI library not found at $_tuiPath" -ForegroundColor Red
    exit 1
}
. $_tuiPath

function Show-Completion {
    Write-Host ""
    Write-Host ""
    Write-Host "  ╭───────────────────────────────────────────╮" -ForegroundColor Green
    Write-Host "  │  🎉 セットアップが完了しました！             │" -ForegroundColor Green
    Write-Host "  ╰───────────────────────────────────────────╯" -ForegroundColor Green
    Write-Host ""
    Write-Host "    インストール先:" -ForegroundColor White
    Write-Host "      SDPM 本体      $SdpmRoot" -ForegroundColor DarkGray
    Write-Host "      コマンド        $LauncherDir\sdpm.cmd" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "    テンプレート・スタイルの登録:" -ForegroundColor White
    Write-Host "      起動後の Web UI から登録できます。" -ForegroundColor DarkGray
    Write-Host "      同梱ファイルはこちら:" -ForegroundColor DarkGray
    Write-Host "        $RootDir\templates\" -ForegroundColor DarkGray
    Write-Host "        $RootDir\styles\" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "    起動方法:" -ForegroundColor White
    Write-Host "      • デスクトップの「pptx-maker」をダブルクリック" -ForegroundColor DarkGray
    Write-Host "      • またはターミナルで: sdpm" -ForegroundColor DarkGray
    Write-Host ""
}
# ── Phase 1: Environment Check ───────────────────────────────────

function Get-DependencyStatus {
    $deps = @()

    # winget
    $hasWinget = Has-Command winget
    $wingetVer = ""; if ($hasWinget) { $wingetVer = "(package manager)" }
    $deps += @{ Name="winget"; Found=$hasWinget; Version=$wingetVer; Required=$true; Reason="auto-install"; WingetId=""; Url="https://aka.ms/getwinget" }

    # git
    $hasGit = Has-Command git
    $gitVer = ""; if ($hasGit) { $gitVer = (git --version).Split(" ")[2] }
    $deps += @{ Name="git"; Found=$hasGit; Version=$gitVer; Required=$true; Reason="latest version fetch"; WingetId="Git.Git"; Url="https://git-scm.com/download/win" }

    # Node.js
    $hasNode = Has-Command node
    $nodeVer = ""; if ($hasNode) { $nodeVer = (node --version) }
    $deps += @{ Name="Node.js"; Found=$hasNode; Version=$nodeVer; Required=$true; Reason="slide engine"; WingetId="OpenJS.NodeJS.LTS"; Url="https://nodejs.org/" }

    # Python
    $hasPython = Has-Command python
    $pyVer = ""
    $pyOk = $false
    if ($hasPython) {
        try {
            $pyVer = python -c "import sys; print(f'{sys.version_info[0]}.{sys.version_info[1]}')" 2>$null
            $pyOk = [version]$pyVer -ge [version]"3.10"
        } catch { $pyOk = $false }
    }
    $pyDisplay = ""; if ($pyOk) { $pyDisplay = $pyVer }
    $deps += @{ Name="Python"; Found=$pyOk; Version=$pyDisplay; Required=$true; Reason="AI integration"; WingetId="Python.Python.3.12"; Url="https://www.python.org/downloads/" }

    # uv
    $hasUv = Has-Command uv
    $uvVer = ""; if ($hasUv) { $uvVer = (uv --version).Split(" ")[-1] }
    $deps += @{ Name="uv"; Found=$hasUv; Version=$uvVer; Required=$true; Reason="Python packages"; WingetId=""; Url="https://docs.astral.sh/uv/" }

    # kiro-cli
    $hasKiro = Has-Command kiro-cli
    $kiroVer = ""; if ($hasKiro) { $kiroVer = "installed" }
    $deps += @{ Name="kiro-cli"; Found=$hasKiro; Version=$kiroVer; Required=$true; Reason="AI service"; WingetId=""; Url="https://cli.kiro.dev/" }

    # LibreOffice
    $soffice = "C:\Program Files\LibreOffice\program\soffice.exe"
    $hasLibre = Test-Path $soffice
    $libreVer = ""
    if ($hasLibre) {
        try { $libreVer = (Get-Item $soffice).VersionInfo.ProductVersion } catch {}
    }
    $deps += @{ Name="LibreOffice"; Found=$hasLibre; Version=$libreVer; Required=$true; Reason="pptx preview"; WingetId="TheDocumentFoundation.LibreOffice"; Url="https://www.libreoffice.org/download/" }

    # poppler (pdftoppm)
    $hasPdftoppm = Has-Command pdftoppm
    $pdftoppmVer = ""; if ($hasPdftoppm) { $pdftoppmVer = "installed" }
    $deps += @{ Name="poppler"; Found=$hasPdftoppm; Version=$pdftoppmVer; Required=$true; Reason="PDF to PNG"; WingetId="oschwartz10612.Poppler"; Url="https://github.com/oschwartz10612/poppler-windows/releases" }

    return $deps
}



# ── Phase 2: Install Dependencies ────────────────────────────────

function Install-Dep-Git {
    Start-Step "git をインストール中" "最新版の取得に必要です"
    $r = Run-WithSpinner -Exe "winget" -Arguments @("install","--id","Git.Git","--silent","--accept-source-agreements","--accept-package-agreements")
    Refresh-Path
    if ((Has-Command git)) {
        Complete-Step "git をインストールしました ($($r.Elapsed))"
    } else {
        Fail-Step "git のインストールに失敗しました" $r.Output "https://git-scm.com/download/win"
        exit 1
    }
}

function Install-Dep-Node {
    Start-Step "Node.js をインストール中" "スライド生成エンジンに必要です"
    $r = Run-WithSpinner -Exe "winget" -Arguments @("install","--id","OpenJS.NodeJS.LTS","--silent","--accept-source-agreements","--accept-package-agreements")
    Refresh-Path
    if ((Has-Command node)) {
        Complete-Step "Node.js をインストールしました ($($r.Elapsed))"
    } else {
        Fail-Step "Node.js のインストールに失敗しました" $r.Output "https://nodejs.org/"
        exit 1
    }
}

function Install-Dep-Python {
    Start-Step "Python をインストール中" "AI連携に必要です"
    $r = Run-WithSpinner -Exe "winget" -Arguments @("install","--id","Python.Python.3.12","--silent","--accept-source-agreements","--accept-package-agreements")
    Refresh-Path
    if ((Has-Command python)) {
        Complete-Step "Python をインストールしました ($($r.Elapsed))"
    } else {
        Fail-Step "Python のインストールに失敗しました" $r.Output "https://www.python.org/downloads/"
        exit 1
    }
}

function Install-Dep-Uv {
    Start-Step "uv をインストール中" "Pythonパッケージ管理に必要です"
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $r = Run-Silent { Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression }
    $sw.Stop()
    $env:Path = "$env:USERPROFILE\.local\bin;$env:Path"
    if ((Has-Command uv)) {
        Complete-Step "uv をインストールしました ($($sw.Elapsed.ToString('mm\:ss')))"
    } else {
        Fail-Step "uv のインストールに失敗しました" $r.Output "https://docs.astral.sh/uv/"
        exit 1
    }
}

function Install-Dep-KiroCli {
    Start-Step "kiro-cli をインストール中" "AI サービス連携に必要です"
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $r = Run-Silent { Invoke-RestMethod 'https://cli.kiro.dev/install.ps1' | Invoke-Expression }
    $sw.Stop()
    Refresh-Path
    if ((Has-Command kiro-cli)) {
        Complete-Step "kiro-cli をインストールしました ($($sw.Elapsed.ToString('mm\:ss')))"
    } else {
        Fail-Step "kiro-cli のインストールに失敗しました" $r.Output "https://cli.kiro.dev/"
        exit 1
    }
}

function Install-Dep-LibreOffice {
    Start-Step "LibreOffice をインストール中" "スライドのプレビューに必要です（約500MB）"

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "cmd.exe"
    $psi.Arguments = "/c winget install --id TheDocumentFoundation.LibreOffice --disable-interactivity --accept-source-agreements --accept-package-agreements"
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $psi.StandardErrorEncoding = [System.Text.Encoding]::UTF8

    $proc = [System.Diagnostics.Process]::Start($psi)
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $frames = @("|","/","-","\")
    $fi = 0

    while (-not $proc.HasExited) {
        $line = $proc.StandardOutput.ReadLine()
        if ($line -match '(\d+)%') {
            $pct = [int]$Matches[1]
            $filled = [int]($pct / 100 * 30)
            $bar = [string]::new([char]0x2501, $filled) + [string]::new([char]0x2500, 30 - $filled)
            $elapsed = $sw.Elapsed.ToString("mm\:ss")
            $frame = $frames[$fi % $frames.Count]
            Write-Host "`r      $frame $bar ${pct}%  $elapsed " -NoNewline -ForegroundColor DarkGray
            $fi++
        }
    }
    $proc.WaitForExit()
    $sw.Stop()
    Write-Host "`r                                                                `r" -NoNewline

    Refresh-Path
    if (Test-Path "C:\Program Files\LibreOffice\program\soffice.exe") {
        Complete-Step "LibreOffice をインストールしました ($($sw.Elapsed.ToString('mm\:ss')))"
    } else {
        $stderr = $proc.StandardError.ReadToEnd()
        Fail-Step "LibreOffice のインストールに失敗しました" $stderr "https://www.libreoffice.org/download/"
        exit 1
    }
}

function Install-Dep-Poppler {
    Start-Step "poppler をインストール中" "PDF→PNG 変換に必要です"
    $r = Run-WithSpinner -Exe "winget" -Arguments @("install","--id","oschwartz10612.Poppler","--silent","--accept-source-agreements","--accept-package-agreements")
    Refresh-Path
    if ((Has-Command pdftoppm)) {
        Complete-Step "poppler をインストールしました ($($r.Elapsed))"
    } else {
        Fail-Step "poppler のインストールに失敗しました" $r.Output "https://github.com/oschwartz10612/poppler-windows/releases"
        exit 1
    }
}

# ── Phase 3: Setup ───────────────────────────────────────────────

function Get-LatestRef {
    param([string]$Path)
    $tag = (git -C $Path tag --sort=-v:refname 2>$null | Select-Object -First 1)
    if ($tag) { return $tag } else { return "main" }
}

function Setup-Oss {
    Start-Step "SDPM 本体をダウンロード中" "-> $SdpmRoot"
    # Prevent "dubious ownership" errors (e.g. network paths, WSL mounts)
    git config --global --add safe.directory $SdpmRoot 2>&1 | Out-Null
    if (Test-Path "$SdpmRoot\.git") {
        $r = Run-WithSpinner -Exe "git" -Arguments @("--no-pager","-C","`"$SdpmRoot`"","fetch","--tags","--prune") -WorkDir $SdpmRoot
        $ref = Get-LatestRef -Path $SdpmRoot
        git -C $SdpmRoot checkout -q $ref 2>&1 | Out-Null
        # Only pull if on a branch (not a detached tag)
        if ($ref -eq "main") {
            git -C $SdpmRoot pull --ff-only 2>&1 | Out-Null
        }
    } else {
        if (Test-Path $SdpmRoot) { Remove-Item -Recurse -Force $SdpmRoot }
        $cloneUrl = "https://github.com/$OssRepo.git"
        $output = & git clone $cloneUrl $SdpmRoot 2>&1 | Out-String
        if ($LASTEXITCODE -ne 0) {
            Fail-Step "ダウンロードに失敗しました" $output "https://github.com/$OssRepo"
            exit 1
        }
        $ref = Get-LatestRef -Path $SdpmRoot
        git -C $SdpmRoot checkout -q $ref 2>$null
    }
    Complete-Step "SDPM 本体を取得しました"
}

function Setup-OssDeps {
    $webUiDir = "$SdpmRoot\web-ui"
    $mcpDir = "$SdpmRoot\mcp-local"
    $needNpm = -not (Test-Path "$webUiDir\node_modules")
    $needUv = -not (Test-Path "$mcpDir\.venv")

    if (-not $needNpm -and -not $needUv) {
        Start-Step "パッケージ（スキップ）" "既にインストール済みです"
        Complete-Step "パッケージは既にインストール済み"
        return
    }

    Start-Step "パッケージをインストール中" "-> $SdpmRoot\web-ui, mcp-local (初回 2-3分)"

    if ($needNpm) {
        $r = Run-WithSpinner -Exe "npm" -Arguments @("ci") -WorkDir $webUiDir
        if (-not $r.Success) {
            Fail-Step "npm ci に失敗しました" $r.Output
            exit 1
        }
    }

    if ($needUv) {
        $r2 = Run-WithSpinner -Exe "uv" -Arguments @("sync") -WorkDir $mcpDir
        if (-not $r2.Success) {
            Fail-Step "uv sync に失敗しました" $r2.Output
            exit 1
        }
    }

    Complete-Step "パッケージをインストールしました"
}

function Setup-Assets {
    Start-Step "設定ファイルを配置中" "-> $UserConfig"
    New-Item -ItemType Directory -Force -Path $UserConfig | Out-Null
    $cfgSrc = Join-Path $KitDir "config.json"
    $cfgDst = Join-Path $UserConfig "config.json"
    if ((Test-Path $cfgSrc) -and (-not (Test-Path $cfgDst))) {
        Copy-Item $cfgSrc $cfgDst
    }
    Complete-Step "設定ファイルを配置しました"
}

function Setup-AwsIcons {
    $ossDest = Join-Path $SdpmRoot "skill\assets\aws"
    if ((Test-Path $ossDest) -and (Test-Path (Join-Path $ossDest "manifest.json"))) {
        Start-Step "AWS アイコン（スキップ）" "既にインストール済みです"
        Complete-Step "AWS アイコンは既にインストール済み"
        return
    }
    Start-Step "AWS アイコンをダウンロード中" "-> $ossDest (公式 AWS Architecture Icons)"
    $scriptPath = Join-Path $SdpmRoot "skill\scripts\download_aws_icons.py"
    $r = Run-WithSpinner -Exe "python" -Arguments @("`"$scriptPath`"") -WorkDir $SdpmRoot -Env @{PYTHONUTF8="1"}
    if ($r.Success) {
        Complete-Step "AWS アイコンをダウンロードしました ($($r.Elapsed))"
    } else {
        Fail-Step "AWS アイコンのダウンロードに失敗しました（後で再試行可能）" $r.Output
    }
}

function Setup-MaterialIcons {
    $ossDest = Join-Path $SdpmRoot "skill\assets\material"
    if ((Test-Path $ossDest) -and (Test-Path (Join-Path $ossDest "manifest.json"))) {
        Start-Step "Material アイコン（スキップ）" "既にインストール済みです"
        Complete-Step "Material アイコンは既にインストール済み"
        return
    }
    Start-Step "Material アイコンをダウンロード中" "-> $ossDest (Google Material Symbols)"
    $scriptPath = Join-Path $SdpmRoot "skill\scripts\download_material_icons.py"
    $r = Run-WithSpinner -Exe "python" -Arguments @("`"$scriptPath`"") -WorkDir $SdpmRoot -Env @{PYTHONUTF8="1"}
    if ($r.Success) {
        Complete-Step "Material アイコンをダウンロードしました ($($r.Elapsed))"
    } else {
        Fail-Step "Material アイコンのダウンロードに失敗しました（後で再試行可能）" $r.Output
    }
}

function Setup-Launcher {
    Start-Step "コマンドを作成中" "-> $LauncherDir\sdpm.cmd"
    New-Item -ItemType Directory -Force -Path $LauncherDir | Out-Null
    $launcher = Join-Path $LauncherDir "sdpm.cmd"
    $launcherContent = @"
@echo off
REM SDPM launcher (generated by sdpm-internal-kit installer)
set SDPM_ROOT=$SdpmRoot
set MARKER_FILE=%SDPM_ROOT%\.update-available

if "%1"=="" goto launch
if "%1"=="launch" goto launch
if "%1"=="path" goto path
if "%1"=="open" goto open
if "%1"=="update" goto update
if "%1"=="check-update" goto checkupdate
if "%1"=="doctor" goto doctor
if "%1"=="version" goto version
if "%1"=="--version" goto version
if "%1"=="help" goto help
if "%1"=="--help" goto help
echo Unknown command: %1
echo Run 'sdpm help' for usage.
exit /b 1

:launch
if exist "%MARKER_FILE%" (
    for /f "tokens=*" %%v in (%MARKER_FILE%) do set NEW_VER=%%v
    echo.
    echo ---------------------------------------------------
    echo   New version available! Latest: %NEW_VER%
    echo   Run 'sdpm update' to upgrade.
    echo ---------------------------------------------------
    echo.
)
start /b cmd /c "call :quietcheck" 2>nul
REM Wait for port 3000 to accept connections, then open the browser.
REM Times out after 120s. Uses 127.0.0.1 to avoid IPv6/IPv4 ambiguity.
start /b powershell -NoProfile -Command "`$sw=[Diagnostics.Stopwatch]::StartNew(); while (`$sw.Elapsed.TotalSeconds -lt 120) { try { `$c=[Net.Sockets.TcpClient]::new(); `$c.Connect('127.0.0.1',3000); `$c.Close(); Start-Process 'http://localhost:3000'; exit } catch { Start-Sleep -Milliseconds 500 } }"
cd /d "%SDPM_ROOT%\web-ui"
set NEXT_PUBLIC_MODE=local
call npx next dev --turbopack
goto :eof

:path
echo %SDPM_ROOT%
goto :eof

:open
if "%2"=="" goto open_help
if "%2"=="app" (explorer "%SDPM_ROOT%" & goto :eof)
if "%2"=="config" (explorer "%APPDATA%\sdpm" & goto :eof)
if "%2"=="templates" (explorer "%APPDATA%\sdpm\templates" & goto :eof)
if "%2"=="styles" (explorer "%APPDATA%\sdpm\styles" & goto :eof)
if "%2"=="icons" (explorer "%SDPM_ROOT%\skill\assets\aws" & goto :eof)
echo Unknown target: %2
:open_help
echo Usage: sdpm open [target]
echo.
echo Targets:
echo   app         SDPM source (%SDPM_ROOT%)
echo   config      User config (%APPDATA%\sdpm)
echo   templates   Templates folder
echo   styles      Styles folder
echo   icons       AWS icons folder
goto :eof

:update
if not exist "%SDPM_ROOT%\.git" (
    echo SDPM_ROOT is not a git repository: %SDPM_ROOT%
    exit /b 1
)
echo Fetching latest changes...
git -C "%SDPM_ROOT%" fetch --tags --prune
set "LATEST_TAG="
for /f %%t in ('git -C "%SDPM_ROOT%" tag --sort=-v:refname') do (
    set "LATEST_TAG=%%t"
    goto :after_tag
)
:after_tag
if defined LATEST_TAG (
    git -C "%SDPM_ROOT%" checkout -q "%LATEST_TAG%"
    echo Checked out latest release: %LATEST_TAG%
) else (
    git -C "%SDPM_ROOT%" checkout -q main
    git -C "%SDPM_ROOT%" pull --ff-only
    echo Updated to latest main
)
pushd "%SDPM_ROOT%\web-ui" && npm ci && popd
pushd "%SDPM_ROOT%\mcp-local" && uv sync && popd
del /q "%MARKER_FILE%" 2>nul
echo Update complete. Run 'sdpm' to launch.
goto :eof

:checkupdate
if not exist "%SDPM_ROOT%\.git" exit /b 1
set "RAW="
for /f "tokens=*" %%i in ('git -C "%SDPM_ROOT%" ls-remote --tags --refs --sort=-v:refname origin 2^>nul ^| findstr /r "refs/tags/"') do (
    set "RAW=%%i"
    goto :parse_latest
)
:parse_latest
REM ls-remote line format: "<sha>\trefs/tags/<tag>". Split by '/' and keep
REM everything after the 2nd delimiter (tokens=2*) so tags containing '/'
REM (e.g. release/1.0) are handled correctly.
set "LATEST="
for /f "tokens=2* delims=/" %%a in ("%RAW%") do set "LATEST=%%b"
set "CURRENT="
for /f "tokens=*" %%c in ('git -C "%SDPM_ROOT%" describe --tags --abbrev=0 2^>nul') do set "CURRENT=%%c"
if not defined LATEST (echo Could not fetch latest tag. && exit /b 1)
if "%LATEST%"=="%CURRENT%" (echo Already on latest: %CURRENT% && del /q "%MARKER_FILE%" 2>nul) else (echo New version: %CURRENT% -^> %LATEST% && echo %LATEST%>"%MARKER_FILE%")
goto :eof

:quietcheck
if not exist "%SDPM_ROOT%\.git" exit /b
set "RAW="
for /f "tokens=*" %%i in ('git -C "%SDPM_ROOT%" ls-remote --tags --refs --sort=-v:refname origin 2^>nul') do (set "RAW=%%i" & goto :qparse)
:qparse
set "QLATEST="
for /f "tokens=2* delims=/" %%a in ("%RAW%") do set "QLATEST=%%b"
set "QCURRENT="
for /f "tokens=*" %%c in ('git -C "%SDPM_ROOT%" describe --tags --abbrev=0 2^>nul') do set "QCURRENT=%%c"
if defined QLATEST if not "%QLATEST%"=="%QCURRENT%" echo %QLATEST%>"%MARKER_FILE%"
exit /b

:version
if exist "%SDPM_ROOT%\.git" (
    for /f "tokens=*" %%i in ('git -C "%SDPM_ROOT%" describe --tags --always 2^>nul') do set "REF=%%i"
    for /f "tokens=*" %%i in ('git -C "%SDPM_ROOT%" rev-parse --short HEAD 2^>nul') do set "COMMIT=%%i"
    echo SDPM version: %REF% (%COMMIT%)
) else (echo SDPM_ROOT is not a git repository: %SDPM_ROOT%)
goto :eof

:doctor
echo Checking SDPM environment...
where git >nul 2>&1 && (for /f "tokens=3" %%i in ('git --version') do echo   git: %%i) || echo   git: not found
where node >nul 2>&1 && (for /f %%i in ('node --version') do echo   Node.js: %%i) || echo   Node.js: not found
where python >nul 2>&1 && (for /f "tokens=*" %%i in ('python --version') do echo   Python: %%i) || echo   Python: not found
where uv >nul 2>&1 && (for /f "tokens=*" %%i in ('uv --version') do echo   uv: %%i) || echo   uv: not found
where kiro-cli >nul 2>&1 && echo   kiro-cli: installed || echo   kiro-cli: not found
where pdftoppm >nul 2>&1 && echo   poppler: installed || echo   poppler: not found
if exist "%SDPM_ROOT%" (echo   SDPM_ROOT: %SDPM_ROOT%) else (echo   SDPM_ROOT missing: %SDPM_ROOT%)
goto :eof

:help
echo Usage: sdpm [COMMAND]
echo.
echo Commands:
echo   launch        Start SDPM Web UI (default, opens browser)
echo   open [target] Open folder in Explorer (app/config/templates/styles/icons)
echo   update        Update OSS to latest release
echo   check-update  Check for updates
echo   version       Show version
echo   path          Print SDPM_ROOT
echo   doctor        Show diagnostics
echo   help          Show this help
goto :eof
"@
    $launcherContent | Set-Content -Path $launcher -Encoding ASCII

    # Add to PATH
    $userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    if ($userPath -notlike "*$LauncherDir*") {
        [System.Environment]::SetEnvironmentVariable("Path", "$userPath;$LauncherDir", "User")
    }
    Complete-Step "sdpm コマンドを作成しました"
}

function Setup-Shortcut {
    Start-Step "ショートカットを作成中" "-> Desktop\pptx-maker.lnk"
    $desktop = [Environment]::GetFolderPath("Desktop")
    if (-not (Test-Path $desktop)) {
        Complete-Step "デスクトップが見つかりません（スキップ）"
        return
    }
    $shortcut = Join-Path $desktop "pptx-maker.lnk"
    $target = Join-Path $LauncherDir "sdpm.cmd"
    $wsh = New-Object -ComObject WScript.Shell
    $sc = $wsh.CreateShortcut($shortcut)
    $sc.TargetPath = $target
    $sc.WorkingDirectory = $LauncherDir
    $sc.Description = "SDPM - Spec-Driven Presentation Maker"
    $sc.Save()
    Complete-Step "デスクトップにショートカットを作成しました"
}

# ── Main ─────────────────────────────────────────────────────────

Show-Header

# Phase 1: Check
Write-Host "    環境を確認しています..." -ForegroundColor DarkGray
Write-Host ""
$deps = Get-DependencyStatus
$missing = $deps | Where-Object { -not $_.Found }

foreach ($d in $deps) {
    Show-Check -Name $d.Name -Version $d.Version -Found $d.Found
}
Write-Host ""

# winget is required for auto-install
$wingetMissing = $deps | Where-Object { $_.Name -eq "winget" -and -not $_.Found }
if ($wingetMissing) {
    Write-Host "    ✗ winget が見つかりません" -ForegroundColor Red
    Write-Host "      Windows 11 には標準搭載されています。" -ForegroundColor DarkGray
    Write-Host "      Microsoft Store から「アプリ インストーラー」をインストールしてください。" -ForegroundColor DarkGray
    Write-Host ""
    exit 1
}

$installNeeded = $missing | Where-Object { $_.Name -ne "winget" }

if ($installNeeded.Count -gt 0) {
    Write-Host "  ─────────────────────────────────────────────" -ForegroundColor DarkGray
    Write-Host "    $($installNeeded.Count) 件のツールをインストールします:" -ForegroundColor White
    Write-Host ""
    foreach ($m in $installNeeded) {
        Write-Host "      • $($m.Name)" -NoNewline -ForegroundColor White
        Write-Host "  — $($m.Reason)" -ForegroundColor DarkGray
    }
    Write-Host ""
    $ok = Show-Confirm "続行しますか？ [Y/n]"
    if (-not $ok) {
        Write-Host ""
        Write-Host "    手動インストール用リンク:" -ForegroundColor Yellow
        foreach ($m in $installNeeded) {
            Write-Host "      $($m.Name): $($m.Url)" -ForegroundColor DarkGray
        }
        Write-Host ""
        Write-Host "    インストール後に再度 Install.cmd を実行してください。" -ForegroundColor DarkGray
        Write-Host ""
        exit 0
    }
} else {
    Write-Host "    すべてのツールが揃っています ✓" -ForegroundColor Green
}

# Calculate total steps
$script:TotalSteps = $installNeeded.Count + 7  # deps + OSS + packages + assets + aws-icons + material-icons + launcher + shortcut

# Phase 2: Install missing dependencies
foreach ($m in $installNeeded) {
    switch ($m.Name) {
        "git"      { Install-Dep-Git }
        "Node.js"  { Install-Dep-Node }
        "Python"   { Install-Dep-Python }
        "uv"       { Install-Dep-Uv }
        "kiro-cli"    { Install-Dep-KiroCli }
        "LibreOffice" { Install-Dep-LibreOffice }
        "poppler"  { Install-Dep-Poppler }
    }
}

# Phase 3: Setup
Setup-Oss
Setup-OssDeps
Setup-Assets
Setup-AwsIcons
Setup-MaterialIcons
Setup-Launcher
Setup-Shortcut

# Phase 4: Completion
Show-Completion

# Run kiro-cli login if not yet authenticated
$prevEAP = $ErrorActionPreference
$ErrorActionPreference = "Continue"
$loginCheck = & kiro-cli login 2>&1 | Out-String
$ErrorActionPreference = $prevEAP
if ($loginCheck -match "Already logged in") {
    Write-Host "    ✓ kiro-cli 認証済み" -ForegroundColor Green
} else {
    Write-Host "    ✓ kiro-cli 認証完了" -ForegroundColor Green
}

Write-Host ""
Write-Host "  ─────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host ""
Write-Host "    準備完了！次回から以下の方法で起動できます:" -ForegroundColor Green
Write-Host ""
Write-Host "      • デスクトップの「pptx-maker」をダブルクリック" -ForegroundColor White
Write-Host "      • またはターミナルで: sdpm" -ForegroundColor White
Write-Host ""
