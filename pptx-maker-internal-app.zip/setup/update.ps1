﻿# SDPM Internal Kit — OSS Updater (TUI) for Windows
#
# Fetches the latest SDPM release from GitHub and reinstalls dependencies.

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"

# ── Configuration ────────────────────────────────────────────────

$KitDir     = Split-Path -Parent $MyInvocation.MyCommand.Path
$RootDir    = Split-Path -Parent $KitDir
$SdpmRoot   = if ($env:SDPM_ROOT) { $env:SDPM_ROOT } else { "$RootDir\sdpm" }
$KitVersion = "0.1.0"

# ── Shared TUI helpers ──────────────────────────────────────────

. (Join-Path $PSScriptRoot 'lib\tui.ps1')

function Show-UpdateCompletion {
    param([string]$From, [string]$To)
    Write-Host ""
    Write-Host ""
    Write-Host "  ╭───────────────────────────────────────────╮" -ForegroundColor Green
    Write-Host "  │  🎉 アップデートが完了しました！             │" -ForegroundColor Green
    Write-Host "  ╰───────────────────────────────────────────╯" -ForegroundColor Green
    Write-Host ""
    Write-Host "    $From → $To" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "    起動方法:" -ForegroundColor White
    Write-Host "      • デスクトップの「pptx-maker」をダブルクリック" -ForegroundColor DarkGray
    Write-Host "      • またはターミナルで: sdpm" -ForegroundColor DarkGray
    Write-Host ""
}

# ── Main ────────────────────────────────────────────────────────

# Header
Clear-Host
Write-Host ""
Write-Host "  ╭───────────────────────────────────────────╮" -ForegroundColor Cyan
Write-Host ("  │  🔄 SDPM アップデート  v{0,-19}│" -f $KitVersion) -ForegroundColor Cyan
Write-Host "  ╰───────────────────────────────────────────╯" -ForegroundColor Cyan
Write-Host ""

# Preflight: SDPM installed?
if (-not (Test-Path "$SdpmRoot\.git")) {
    Write-Host "    ✗ SDPM がまだインストールされていません" -ForegroundColor Red
    Write-Host "      $SdpmRoot" -ForegroundColor DarkGray
    Write-Host "      先に Install (Windows).cmd を実行してください。" -ForegroundColor DarkGray
    Write-Host ""
    exit 1
}

git config --global --add safe.directory $SdpmRoot 2>&1 | Out-Null

Write-Host "    バージョンを確認しています..." -ForegroundColor DarkGray
Write-Host ""

$current = (git -C $SdpmRoot describe --tags --abbrev=0 2>$null)
if (-not $current) { $current = "?" }

# Latest tag from remote
$lsRemote = (git -C $SdpmRoot ls-remote --tags --refs --sort=-v:refname origin 2>$null)
$latest = $null
if ($lsRemote) {
    $firstLine = ($lsRemote -split "`n")[0]
    # format: "<sha>\trefs/tags/<tag>"
    if ($firstLine -match 'refs/tags/(.+)$') {
        $latest = $Matches[1].Trim()
    }
}
if (-not $latest) {
    Write-Host "    ✗ GitHub から最新バージョンを取得できませんでした" -ForegroundColor Red
    Write-Host "      ネットワーク接続を確認してください。" -ForegroundColor DarkGray
    Write-Host ""
    exit 1
}

Write-Host "    現在  " -NoNewline
Write-Host "$current" -ForegroundColor Green
Write-Host "    最新  " -NoNewline
Write-Host "$latest" -ForegroundColor Cyan
Write-Host ""

if ($current -eq $latest) {
    Write-Host "  ─────────────────────────────────────────────" -ForegroundColor DarkGray
    Write-Host "    既に最新バージョンです ✓" -ForegroundColor Green
    Write-Host ""
    Remove-Item "$SdpmRoot\.update-available" -ErrorAction SilentlyContinue
    exit 0
}

Write-Host "  ─────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host "    新しいバージョンをインストールします。"
$ok = Show-Confirm "続行しますか？ [Y/n]"
if (-not $ok) {
    Write-Host ""
    Write-Host "    キャンセルしました。" -ForegroundColor Yellow
    Write-Host ""
    exit 0
}

# Step counter
$script:TotalSteps = 3
$script:CurrentStep = 0

# Step 1: fetch + checkout
Start-Step "最新コードを取得中" "-> $latest"
$r = Run-WithSpinner -Exe "git" -Arguments @("-C", $SdpmRoot, "fetch", "--tags", "--prune")
if (-not $r.Success) {
    Fail-Step "fetch に失敗しました" $r.Output "https://github.com/aws-samples/sample-spec-driven-presentation-maker"
    exit 1
}
git -C $SdpmRoot checkout -q $latest 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    Fail-Step "checkout に失敗しました ($latest)"
    exit 1
}
Complete-Step "$latest に更新しました ($($r.Elapsed))"

# Step 2: web-ui deps
Start-Step "Web UI パッケージを更新中" "-> npm ci (初回 1-2 分)"
$r = Run-WithSpinner -Exe "npm" -Arguments @("ci") -WorkDir "$SdpmRoot\web-ui"
if ($r.Success) {
    Complete-Step "Web UI パッケージを更新しました ($($r.Elapsed))"
} else {
    Fail-Step "npm ci に失敗しました" $r.Output
    exit 1
}

# Step 3: mcp-local deps
Start-Step "MCP パッケージを更新中" "-> uv sync"
$r = Run-WithSpinner -Exe "uv" -Arguments @("sync") -WorkDir "$SdpmRoot\mcp-local"
if ($r.Success) {
    Complete-Step "MCP パッケージを更新しました ($($r.Elapsed))"
} else {
    Fail-Step "uv sync に失敗しました" $r.Output
    exit 1
}

Remove-Item "$SdpmRoot\.update-available" -ErrorAction SilentlyContinue

Show-UpdateCompletion -From $current -To $latest
