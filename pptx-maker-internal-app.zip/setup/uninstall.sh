#!/bin/bash
# SDPM Internal Kit — Uninstaller for macOS / Linux

set -uo pipefail

KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$KIT_DIR/.." && pwd)"
SDPM_ROOT="${SDPM_ROOT:-$ROOT_DIR/sdpm}"
USER_CONFIG="${XDG_CONFIG_HOME:-$HOME/.config}/sdpm"
LAUNCHER="$HOME/.local/bin/sdpm"

OS="$(uname -s)"
case "$OS" in
  Darwin) OS_TYPE="macos" ;;
  Linux)  OS_TYPE="linux" ;;
  *) echo "Unsupported OS: $OS" >&2; exit 1 ;;
esac

if [[ "$OS_TYPE" == "macos" ]]; then
  SHORTCUT="$HOME/Desktop/pptx-maker.command"
else
  SHORTCUT="$HOME/.local/share/applications/pptx-maker.desktop"
fi

if [[ -t 1 ]]; then
  C_RED=$'\033[31m'; C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'; C_DIM=$'\033[2m'; C_RESET=$'\033[0m'
else
  C_RED=''; C_GREEN=''; C_YELLOW=''; C_DIM=''; C_RESET=''
fi

echo ""
printf "  ${C_RED}╭───────────────────────────────────────────╮${C_RESET}\n"
printf "  ${C_RED}│  🗑  SDPM アンインストール                  │${C_RESET}\n"
printf "  ${C_RED}╰───────────────────────────────────────────╯${C_RESET}\n"
echo ""
printf "    以下を削除します:\n"
echo ""

targets=()
add_target() { [[ -e "$1" ]] && { targets+=("$1"); printf "      ${C_DIM}• %s${C_RESET}\n" "$1"; }; }

add_target "$SDPM_ROOT"
add_target "$USER_CONFIG"
add_target "$LAUNCHER"
add_target "$SHORTCUT"

if [[ ${#targets[@]} -eq 0 ]]; then
  printf "      ${C_DIM}(削除対象が見つかりません)${C_RESET}\n"
  echo ""
  exit 0
fi

echo ""
printf "    ${C_DIM}※ Node.js, Python, git, LibreOffice 等は他で使われている可能性があるため残します${C_RESET}\n"
echo ""
read -r -p "    削除しますか？ [y/N] " reply
case "${reply:-n}" in
  [Yy]*) ;;
  *) echo ""; printf "    ${C_YELLOW}キャンセルしました。${C_RESET}\n"; echo ""; exit 0 ;;
esac

echo ""
for t in "${targets[@]}"; do
  if rm -rf "$t" 2>/dev/null; then
    printf "    ${C_GREEN}✓${C_RESET} 削除: %s\n" "$t"
  else
    printf "    ${C_RED}✗${C_RESET} 削除失敗: %s\n" "$t"
  fi
done

echo ""
printf "    ${C_GREEN}アンインストールが完了しました。${C_RESET}\n"
echo ""
