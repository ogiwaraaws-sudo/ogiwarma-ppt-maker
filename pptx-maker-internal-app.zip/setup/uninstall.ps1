﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$KitDir      = Split-Path -Parent $MyInvocation.MyCommand.Path
$RootDir     = Split-Path -Parent $KitDir
$SdpmRoot    = if ($env:SDPM_ROOT) { $env:SDPM_ROOT } else { "$RootDir\sdpm" }
$UserConfig  = "$env:APPDATA\sdpm"
$LauncherDir = "$env:USERPROFILE\bin"
$Launcher    = "$LauncherDir\sdpm.cmd"
$Desktop     = [Environment]::GetFolderPath("Desktop")
$Shortcut    = "$Desktop\pptx-maker.lnk"

Write-Host ""
Write-Host "  ╭───────────────────────────────────────────╮" -ForegroundColor Red
Write-Host "  │  🗑  SDPM アンインストール                  │" -ForegroundColor Red
Write-Host "  ╰───────────────────────────────────────────╯" -ForegroundColor Red
Write-Host ""
Write-Host "    以下を削除します:" -ForegroundColor White
Write-Host ""

$targets = @()
if (Test-Path $SdpmRoot)   { $targets += $SdpmRoot;   Write-Host "      • $SdpmRoot" -ForegroundColor DarkGray }
if (Test-Path $UserConfig) { $targets += $UserConfig; Write-Host "      • $UserConfig" -ForegroundColor DarkGray }
if (Test-Path $Launcher)   { $targets += $Launcher;   Write-Host "      • $Launcher" -ForegroundColor DarkGray }
if (Test-Path $Shortcut)   { $targets += $Shortcut;   Write-Host "      • $Shortcut" -ForegroundColor DarkGray }

if ($targets.Count -eq 0) {
    Write-Host "      (削除対象が見つかりません)" -ForegroundColor DarkGray
    Write-Host ""
    exit 0
}

Write-Host ""
Write-Host "    ※ Node.js, Python, git 等は他で使われている可能性があるため残します" -ForegroundColor DarkGray
Write-Host ""
$reply = Read-Host "    削除しますか？ [y/N]"
if ($reply -notmatch "^[Yy]") {
    Write-Host ""
    Write-Host "    キャンセルしました。" -ForegroundColor Yellow
    Write-Host ""
    exit 0
}

Write-Host ""
foreach ($t in $targets) {
    Remove-Item -Recurse -Force $t -ErrorAction SilentlyContinue
    Write-Host "    ✓ 削除: $t" -ForegroundColor Green
}

# Remove from PATH
$userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -like "*$LauncherDir*") {
    $newPath = ($userPath -split ";" | Where-Object { $_ -ne $LauncherDir }) -join ";"
    [System.Environment]::SetEnvironmentVariable("Path", $newPath, "User")
    Write-Host "    ✓ PATH から削除: $LauncherDir" -ForegroundColor Green
}

Write-Host ""
Write-Host "    アンインストールが完了しました。" -ForegroundColor Green
Write-Host ""
