﻿# SDPM Internal Kit — shared TUI helpers (Windows)
# Usage: . (Join-Path $PSScriptRoot '..\lib\tui.ps1')
#
# State: $script:TotalSteps, $script:CurrentStep


$script:TotalSteps = 0
$script:CurrentStep = 0

function Show-Header {
    Clear-Host
    Write-Host ""
    Write-Host "  ╭───────────────────────────────────────────╮" -ForegroundColor Cyan
    Write-Host "  │  🚀 SDPM セットアップ  v$KitVersion              │" -ForegroundColor Cyan
    Write-Host "  ╰───────────────────────────────────────────╯" -ForegroundColor Cyan
    Write-Host ""
}

function Show-Check {
    param([string]$Name, [string]$Version, [bool]$Found)
    if ($Found) {
        Write-Host "    ✓ " -ForegroundColor Green -NoNewline
        Write-Host "$Name" -NoNewline
        Write-Host " $Version" -ForegroundColor DarkGray
    } else {
        Write-Host "    ✗ " -ForegroundColor Red -NoNewline
        Write-Host "$Name" -NoNewline
        Write-Host " 未インストール" -ForegroundColor DarkGray
    }
}

function Show-Progress {
    $pct = if ($script:TotalSteps -gt 0) { [int]($script:CurrentStep / $script:TotalSteps * 40) } else { 0 }
    $bar = "━" * $pct + "─" * (40 - $pct)
    Write-Host "`r  $bar $($script:CurrentStep)/$($script:TotalSteps)" -NoNewline -ForegroundColor DarkGray
}

function Start-Step {
    param([string]$Message, [string]$Detail)
    $script:CurrentStep++
    Write-Host ""
    Show-Progress
    Write-Host ""
    Write-Host "    ● $Message" -ForegroundColor Cyan -NoNewline
    Write-Host "  [$($script:CurrentStep)/$($script:TotalSteps)]" -ForegroundColor DarkGray
    if ($Detail) {
        Write-Host "      $Detail" -ForegroundColor DarkGray
    }
}

function Complete-Step {
    param([string]$Message)
    # Move cursor up to overwrite the ● line
    Write-Host "`r    ✓ $Message" -ForegroundColor Green
}

function Fail-Step {
    param([string]$Message, [string]$Log, [string]$HelpUrl)
    Write-Host "`r    ✗ $Message" -ForegroundColor Red
    if ($Log) {
        Write-Host ""
        Write-Host "    ┌ 詳細ログ ─────────────────────────────────" -ForegroundColor DarkGray
        $Log -split "`n" | Select-Object -Last 10 | ForEach-Object {
            Write-Host "    │ $_" -ForegroundColor DarkGray
        }
        Write-Host "    └───────────────────────────────────────────" -ForegroundColor DarkGray
    }
    if ($HelpUrl) {
        Write-Host ""
        Write-Host "    手動でインストールしてください:" -ForegroundColor Yellow
        Write-Host "      $HelpUrl" -ForegroundColor Yellow
    }
}

function Show-Confirm {
    param([string]$Prompt)
    Write-Host ""
    Write-Host "  $Prompt" -NoNewline
    $reply = Read-Host " "
    return ($reply -eq "" -or $reply -match "^[Yy]")
}


function Run-WithSpinner {
    param([string]$Exe, [string[]]$Arguments, [string]$WorkDir, [hashtable]$Env)
    $frames = @("|","/","-","\")
    $i = 0
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $psi.StandardErrorEncoding = [System.Text.Encoding]::UTF8

    # Resolve exe path and determine if it's a batch file
    $resolved = (Get-Command $Exe -ErrorAction SilentlyContinue).Source
    if (-not $resolved) { $resolved = $Exe }
    $isBatch = $resolved -match '\.(cmd|bat)$'

    if ($isBatch) {
        # .cmd/.bat must run via cmd.exe
        $psi.FileName = "cmd.exe"
        $argsLine = $Arguments -join ' '
        $psi.Arguments = "/c `"$resolved`" $argsLine"
    } else {
        $psi.FileName = $resolved
        $psi.Arguments = $Arguments -join ' '
    }

    if ($WorkDir) { $psi.WorkingDirectory = $WorkDir }

    # Inject additional environment variables
    if ($Env) {
        foreach ($key in $Env.Keys) {
            $psi.EnvironmentVariables[$key] = $Env[$key]
        }
    }

    $proc = [System.Diagnostics.Process]::Start($psi)

    # Async read to prevent pipe buffer deadlock
    $outTask = $proc.StandardOutput.ReadToEndAsync()
    $errTask = $proc.StandardError.ReadToEndAsync()

    while (-not $proc.HasExited) {
        $elapsed = $sw.Elapsed.ToString("mm\:ss")
        $frame = $frames[$i % $frames.Count]
        Write-Host "`r      $frame $elapsed " -NoNewline -ForegroundColor DarkGray
        Start-Sleep -Milliseconds 80
        $i++
    }
    $proc.WaitForExit()
    $sw.Stop()

    $stdout = $outTask.Result
    $stderr = $errTask.Result
    $exitCode = $proc.ExitCode

    # Clear spinner line
    Write-Host "`r                          `r" -NoNewline

    $elapsed = $sw.Elapsed.ToString("mm\:ss")
    return @{ Success = ($exitCode -eq 0); Output = "$stdout`n$stderr"; Elapsed = $elapsed; ExitCode = $exitCode }
}

function Run-Silent {
    param([scriptblock]$Command)
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $output = ""
    try {
        $output = & $Command 2>&1 | Out-String
    } catch {
        $ErrorActionPreference = $prevEAP
        return @{ Success = $false; Output = "$output`n$($_.Exception.Message)" }
    }
    $ErrorActionPreference = $prevEAP
    return @{ Success = $true; Output = $output }
}

function Has-Command($name) {
    return [bool](Get-Command $name -ErrorAction SilentlyContinue)
}

function Refresh-Path {
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
}
