# SDPM Internal Kit — shared TUI helpers
#
# Usage:  source "$KIT_DIR/lib/tui.sh"
#
# Exports:
#   show_header <title>
#   show_check <name> <version> <found:0|1>
#   show_progress
#   start_step <msg> [detail]
#   complete_step <msg>
#   fail_step <msg> [log] [help_url]
#   show_confirm <prompt>
#   has_command <name>
#   run_with_spinner <cmd> [workdir]       (populates LAST_LOG, LAST_ELAPSED)
#
# State variables (caller can read/write):
#   TOTAL_STEPS, CURRENT_STEP, LAST_LOG, LAST_ELAPSED

if [[ -t 1 ]]; then
  C_CYAN=$'\033[36m'
  C_GREEN=$'\033[32m'
  C_RED=$'\033[31m'
  C_YELLOW=$'\033[33m'
  C_DIM=$'\033[2m'
  C_RESET=$'\033[0m'
else
  C_CYAN=''; C_GREEN=''; C_RED=''; C_YELLOW=''; C_DIM=''; C_RESET=''
fi

TOTAL_STEPS=${TOTAL_STEPS:-0}
CURRENT_STEP=${CURRENT_STEP:-0}
LAST_LOG=${LAST_LOG:-""}
LAST_ELAPSED=${LAST_ELAPSED:-""}

show_header() {
  # Args: <title-prefix>  <version>
  # Title is expected to be ~20 visual cols wide (e.g. "🚀 SDPM セットアップ").
  # Version is right-padded to 19 chars so the closing │ lines up.
  local title="$1" version="${2:-}"
  clear 2>/dev/null || printf '\033c'
  echo ""
  printf "  ${C_CYAN}╭───────────────────────────────────────────╮${C_RESET}\n"
  if [[ -n "$version" ]]; then
    printf "  ${C_CYAN}│  %s  v%-19s│${C_RESET}\n" "$title" "$version"
  else
    printf "  ${C_CYAN}│  %s${C_RESET}\n" "$title"
  fi
  printf "  ${C_CYAN}╰───────────────────────────────────────────╯${C_RESET}\n"
  echo ""
}

show_check() {
  local name="$1" version="$2" found="$3"
  if [[ "$found" == "1" ]]; then
    printf "    ${C_GREEN}✓${C_RESET} %s ${C_DIM}%s${C_RESET}\n" "$name" "$version"
  else
    printf "    ${C_RED}✗${C_RESET} %s ${C_DIM}未インストール${C_RESET}\n" "$name"
  fi
}

show_progress() {
  local pct=0 i
  if [[ $TOTAL_STEPS -gt 0 ]]; then
    pct=$(( CURRENT_STEP * 40 / TOTAL_STEPS ))
  fi
  local bar=""
  for (( i=0; i<pct; i++ )); do bar="${bar}━"; done
  for (( i=pct; i<40; i++ )); do bar="${bar}─"; done
  printf "\r  ${C_DIM}%s${C_RESET} %d/%d" "$bar" "$CURRENT_STEP" "$TOTAL_STEPS"
}

start_step() {
  local msg="$1" detail="${2:-}"
  CURRENT_STEP=$(( CURRENT_STEP + 1 ))
  echo ""
  show_progress
  echo ""
  printf "    ${C_CYAN}●${C_RESET} %s  ${C_DIM}[%d/%d]${C_RESET}\n" "$msg" "$CURRENT_STEP" "$TOTAL_STEPS"
  if [[ -n "$detail" ]]; then
    printf "      ${C_DIM}%s${C_RESET}\n" "$detail"
  fi
}

complete_step() {
  local msg="$1"
  printf "\r    ${C_GREEN}✓${C_RESET} %s\n" "$msg"
}

fail_step() {
  local msg="$1" log="${2:-}" help_url="${3:-}"
  printf "\r    ${C_RED}✗${C_RESET} %s\n" "$msg"
  if [[ -n "$log" ]]; then
    echo ""
    printf "    ${C_DIM}┌ 詳細ログ ─────────────────────────────────${C_RESET}\n"
    echo "$log" | tail -n 10 | while IFS= read -r line; do
      printf "    ${C_DIM}│ %s${C_RESET}\n" "$line"
    done
    printf "    ${C_DIM}└───────────────────────────────────────────${C_RESET}\n"
  fi
  if [[ -n "$help_url" ]]; then
    echo ""
    printf "    ${C_YELLOW}手動でインストールしてください:${C_RESET}\n"
    printf "      ${C_YELLOW}%s${C_RESET}\n" "$help_url"
  fi
}

show_confirm() {
  local prompt="$1" reply
  echo ""
  read -r -p "  $prompt " reply
  case "${reply:-y}" in [Yy]*|"") return 0 ;; *) return 1 ;; esac
}

has_command() { command -v "$1" >/dev/null 2>&1; }

run_with_spinner() {
  local cmd="$1" workdir="${2:-}"
  local log_file
  log_file="$(mktemp)"
  local frames=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
  local start
  start=$(date +%s)

  if [[ -n "$workdir" ]]; then
    ( cd "$workdir" && eval "$cmd" ) >"$log_file" 2>&1 &
  else
    eval "$cmd" >"$log_file" 2>&1 &
  fi
  local pid=$! i=0
  while kill -0 "$pid" 2>/dev/null; do
    local elapsed=$(( $(date +%s) - start ))
    printf "\r      ${C_DIM}%s %02d:%02d${C_RESET} " "${frames[$(( i % 10 ))]}" $(( elapsed / 60 )) $(( elapsed % 60 ))
    i=$(( i + 1 ))
    sleep 0.1
  done
  wait "$pid" 2>/dev/null
  local rc=$?
  local elapsed=$(( $(date +%s) - start ))
  LAST_ELAPSED=$(printf "%02d:%02d" $(( elapsed / 60 )) $(( elapsed % 60 )))
  LAST_LOG="$(cat "$log_file")"
  rm -f "$log_file"
  printf "\r                          \r"
  return $rc
}
