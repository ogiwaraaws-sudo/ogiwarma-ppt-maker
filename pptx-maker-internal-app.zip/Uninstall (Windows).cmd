@echo off
REM pptx-maker - Uninstaller for Windows
REM Double-click this file to uninstall.

cd /d "%~dp0"
chcp 65001 >nul 2>&1

powershell -NoProfile -Command "Get-ChildItem -Path '%~dp0setup' -Recurse -Filter *.ps1 | Unblock-File" >nul 2>&1

powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0setup\uninstall.ps1"

echo.
pause
